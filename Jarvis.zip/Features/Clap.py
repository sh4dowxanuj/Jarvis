import sounddevice as sd
import numpy as np

def detect_clap(threshold=0.02, duration=1.0):
    """Detects a loud sound (clap) based on amplitude threshold."""
    print("Listening for a clap...")
    
    def callback(indata, frames, time, status):
        volume_norm = np.linalg.norm(indata) * 10
        if volume_norm > threshold:
            print("Clap detected!")
            return True

    with sd.InputStream(callback=callback, channels=1):
        sd.sleep(int(duration * 1000))

    return False

if __name__ == "__main__":
    if detect_clap():
        print("AI Assistant Activated!")
