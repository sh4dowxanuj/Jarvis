import os

API_FILE = "Data/Api.txt"

def get_api_key():
    """Retrieves the API key from the file."""
    if os.path.exists(API_FILE):
        with open(API_FILE, "r") as file:
            return file.read().strip()
    else:
        print("API key file not found! Please add your API key to Data/Api.txt.")
        return None

if __name__ == "__main__":
    api_key = get_api_key()
    if api_key:
        print("API Key Loaded Successfully!")
