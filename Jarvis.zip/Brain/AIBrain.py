from transformers import pipeline

class Brain:
    def __init__(self):
        """Initialize the AI model from Hugging Face."""
        self.chatbot = pipeline("conversational", model="facebook/blenderbot-400M-distill")

    def process_text(self, user_input):
        """Processes user input and returns AI-generated response."""
        response = self.chatbot(user_input)
        return response[0]['generated_text']

if __name__ == "__main__":
    ai_brain = Brain()
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        response = ai_brain.process_text(user_input)
        print("AI:", response)
