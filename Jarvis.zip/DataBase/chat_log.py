import datetime

LOG_FILE = "DataBase/chat_log.txt"

def log_conversation(user_input, ai_response):
    """Logs the conversation to a text file with timestamps."""
    with open(LOG_FILE, "a") as file:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"[{timestamp}] You: {user_input}\n")
        file.write(f"[{timestamp}] AI: {ai_response}\n\n")

if __name__ == "__main__":
    log_conversation("Hello", "Hi there! How can I assist you?")
    print("Conversation logged.")
