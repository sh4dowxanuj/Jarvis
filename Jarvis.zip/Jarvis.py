from Body.Listen import listen
from Body.Speak import speak
from Brain.AIBrain import Brain
from Features.Clap import detect_clap
from DataBase.chat_log import log_conversation

def jarvis():
    """Main loop for the AI Assistant."""
    ai_brain = Brain()

    speak("Jarvis is now active. Waiting for your command...")
    
    while True:
        if detect_clap():
            speak("I'm listening...")

        user_input = listen()
        if not user_input:
            continue
        
        if user_input.lower() in ["exit", "quit", "stop"]:
            speak("Goodbye!")
            break

        response = ai_brain.process_text(user_input)
        speak(response)
        log_conversation(user_input, response)

if __name__ == "__main__":
    jarvis()
