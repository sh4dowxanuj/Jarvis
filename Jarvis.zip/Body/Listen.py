import speech_recognition as sr

def listen():
    """Captures voice input and converts it to text."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)  # Adjust for background noise
        try:
            audio = recognizer.listen(source)  # Capture audio
            text = recognizer.recognize_google(audio)  # Convert to text using Google API
            print(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            print("Sorry, I couldn't understand that.")
            return ""
        except sr.RequestError:
            print("Could not request results, check your internet connection.")
            return ""

if __name__ == "__main__":
    while True:
        command = listen()
        if command.lower() in ["exit", "quit"]:
            break
