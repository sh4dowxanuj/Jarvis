import pyttsx3

engine = pyttsx3.init()

def speak(text):
    """Converts text to speech and speaks it out."""
    engine.say(text)
    engine.runAndWait()

if __name__ == "__main__":
    speak("Hello! I am your AI assistant.")
